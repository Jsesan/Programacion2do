/**//* 42.393.167-SESAN,JuanIgnacio-(06-2965) *//**/

#include "Figura.h"

Figura::~Figura()
{

}

